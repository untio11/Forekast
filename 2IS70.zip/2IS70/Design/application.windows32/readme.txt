--- Prototype Forekast app ---

1. Make sure to have the latest version of Java 8 installed. 
2. Launch Design.exe
3. Clickable buttons are highlighted in blue when hovering over them.
   a. In T-Shirts menu, only the yellow shirt is editable.
      In jeans menu, only the black jeans are editable.
   b. In the edit menu, the overall rating (the heart) is also adjustable.
   c. In camera mode, click anywhere to continue.
4. DO NOT navigate through the tabs at the top of the screen.
5. This prototype does not show full functionality and changes to the design can be made.