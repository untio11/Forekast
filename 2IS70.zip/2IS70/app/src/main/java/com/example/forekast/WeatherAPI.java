package com.example.forekast;

class WeatherAPI extends WeatherAPIInterface {

    @Override
    Weather getWeather() {
        return null;
    }
}
