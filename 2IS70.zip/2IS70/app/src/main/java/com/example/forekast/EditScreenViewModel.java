package com.example.forekast;

import android.arch.lifecycle.ViewModel;

public class EditScreenViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
