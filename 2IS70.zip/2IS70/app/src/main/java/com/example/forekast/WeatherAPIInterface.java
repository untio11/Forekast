package com.example.forekast;

abstract class WeatherAPIInterface {

    abstract Weather getWeather();
}
