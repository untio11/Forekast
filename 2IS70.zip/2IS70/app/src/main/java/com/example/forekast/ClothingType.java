package com.example.forekast;

enum ClothingType {
    T_SHIRT,
    JACKET,
    DRESS,
    SHIRT,
    SWEATER,
    TANKTOP,
    SHORTS,
    JEANS,
    SKIRT,
    TROUSERS,
    SNEAKERS,
    BOOTS,
    SANDALS,
    SHOES
}
