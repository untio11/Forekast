package com.example.forekast;

import java.util.List;

abstract class OutfitPowersetInterface {

    List<Clothing> inner_top;
    List<Clothing> outer_top;
    List<Clothing> pants;
    List<Clothing> shoes;
}
