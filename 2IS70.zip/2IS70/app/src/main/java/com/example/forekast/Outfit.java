package com.example.forekast;

abstract class Outfit {

    Clothing inner_torso;
    Clothing outer_torso;
    Clothing pants;
    Clothing shoes;
    Boolean coat;
    Boolean gloves;
    Boolean umbrella;
    Boolean sunglasses;
}
